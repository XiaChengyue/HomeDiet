<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		},
		globalData: {
			openid: 1777
		}
	}
</script>

<style>
	page {
		background-color: #f5f5f5;
	}

</style>
