<template>
	<view>
		
	</view>
</template>

<script>
	export default {
		name:"goods-card",
		data() {
			return {
				
			};
		}
	}
</script>

<style>

</style>
