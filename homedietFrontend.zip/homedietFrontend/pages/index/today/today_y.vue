<template>
	<view>
		<view class="upper">
			<image mode="aspectFit"  :src="picUrl"></image>
			<text>{{name}}</text>
			<text @click="clickText()">个人信息 ></text>
		</view>
		<view>
		<scroll-view class="middle" scroll-y>
			<view class="first">
				<text>体重趋势</text>
				<image mode="aspectFit" src="../../../static/index/line.jpg"></image>
			</view>
			
			 <view class="second">
				 <view class="second_in">
				 	<text>基础代谢率</text>
				 	<text>{{dat1}}kcal</text>
				 </view>
				 <view class="second_in">
				<text>每日消耗热量</text>
				<text>{{dat2}}kcal</text>
				 </view>
				 <view class="second_in">
				<text>减脂每日摄入</text>
				<text>{{dat3}}kcal</text>
				 </view>


			</view> 
		
			
			<view class="third">
				<view class="title">
				<view>三大元素配比</view>
				<text>———————————————————</text>
				</view>
				<view class="second_in">
					<text>蛋白质</text>
					<text>{{dat4}}g</text>
				</view>
				<view class="second_in">
					<text>碳水化合物</text>
					<text>{{dat5}}g</text>
				</view>
				<view class="second_in">
					<text>脂肪</text>
					<text>{{dat6}}g</text>
				</view>
			</view>
			
		</scroll-view>
			</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				name:"Paul",
				picUrl:"../../static/mine/user.jpg",
				sex: 0,
				sex_string: "",
				weight: 0,
				height: 0,
				age: 0,
				bfr: 0,
				tdee: 0,
		
				

				dat1 : 100,
				dat2 : 0,
				dat3 : 0,
				dat4 : 100,
				dat5 : 0,
				dat6 : 0,
				id:0
			}
		},
		onLoad(options) {
			this.name=getApp().globalData.nickName
			this.picUrl=getApp().globalData.avatarUrl
			this.getUser()
			
			


		},
		
		components: {},
		methods: {
			clickText: function(){
				uni.navigateTo({
					url : 'personal_info?exist=1&id='+this.id
				})
			},
			async getUser(){
				const res = await this.$myRequest({
					url: '/user?openid=' + getApp().globalData.openid
				})
				 const that = this
				Promise.all([res]).then(() => {
				 that.dat1 = res.data.data[0].bmr
				 that.dat2 = res.data.data[0].tdee
				 that.dat3 = res.data.data[0].cal
				 that.dat4 = res.data.data[0].pro
				 that.dat5 = res.data.data[0].cho
				 that.dat6 = res.data.data[0].fat
				 that.id = res.data.data[0].id
				})
			}
		},
	}
</script>

<style lang="scss">
	.upper{

		width: 375px;
		height: 100px;
		line-height: 20px;
		background-color: rgba(0, 80, 179, 100);
		color: rgba(16, 16, 16, 100);
		font-size: 14px;
		text-align: center;
		font-family: Arial;
		image{
			left: 45px;
			top: 22px;
			width: 60px;
			height: 60px;
			position: absolute;
		}
		
		text{
			left: 121px;
			top: 22px;
			width: 42px;
			height: 20px;
			color: rgba(255, 255, 255, 100);
			font-size: 14px;
			text-align: left;
			font-family: PingFangSC-regular;
			position: absolute;
		}
		
		text:nth-of-type(2){
			left: 282px;
			top: 22px;
			width: 80px;
			height: 20px;
			color: rgba(255, 255, 255, 100);
			font-size: 14px;
			text-align: left;
			font-family: PingFangSC-regular;
			position: absolute;
		}
		
		text:nth-of-type(3){
			left: 300px;
			top: 42px;
			width: 80px;
			height: 20px;
			color: rgba(255, 255, 255, 100);
			font-size: 14px;
			text-align: left;
			font-family: PingFangSC-regular;
			position: absolute;
		}
	}

	.middle{
		height:650px;
		.first{
			background-color: rgba(255, 255, 255, 100);
			height: 273px;
			width: 328px;
			border-radius: 15px;
			border: 1px solid #BBBBBB;
			padding-top: 15px;
			font-size: 14px;
            margin-top: 20px;
			margin-left: 23px;
			text{
				margin-left: 20px;
			}
			image{
				width: 90%;
				height: 90%;
				margin-left: 20px;
			}
		}
		
		.second{
			background-color: rgba(255, 255, 255, 100);
			height: 130px;
			width: 328px;
			border-radius: 15px;
			border: 1px solid #BBBBBB;
			padding-top: 15px;
			margin-left: 23px;
			font-size: 14px;
			margin-top: 20px;
		}
		.second_in{
			display: flex;
			justify-content: space-between;
			width: 80%;
			margin: auto;
			margin-top: 15px;
			
		}
		
		.third{
            background-color: rgba(255, 255, 255, 100);
			height: 200px;
			width: 328px;
			border-radius: 15px;
			border: 1px solid #BBBBBB;
			font-size: 14px;
			margin-top: 20px;
			margin-left: 23px;
		}
		.title{
			margin-left: 30px;
			margin-top: 15px;
		}
	
	}
	
</style>