package com.example.homediet.common;

public interface IErrorCode {
    Integer getCode();
    String getMessage();
}
