package com.example.homediet.service;

import com.example.homediet.entity.Item;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xia
 * @since 2022-05-23
 */
public interface IItemService extends IService<Item> {

}
