package com.example.homediet.service;

import com.example.homediet.entity.Cart;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xia
 * @since 2022-05-23
 */
public interface ICartService extends IService<Cart> {

}
