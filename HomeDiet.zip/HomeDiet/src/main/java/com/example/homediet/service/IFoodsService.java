package com.example.homediet.service;

import com.example.homediet.entity.Foods;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xia
 * @since 2022-04-17
 */
public interface IFoodsService extends IService<Foods> {

}
