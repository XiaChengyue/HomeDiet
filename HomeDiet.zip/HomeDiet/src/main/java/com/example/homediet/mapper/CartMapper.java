package com.example.homediet.mapper;

import com.example.homediet.entity.Cart;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author xia
 * @since 2022-05-23
 */
public interface CartMapper extends BaseMapper<Cart> {

}
